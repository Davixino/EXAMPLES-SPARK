#!/usr/bin/python3

import sys

from pyspark.sql import SparkSession

'''
Programa creado por Ronald Jimenez
'''
def clavevalor(line):
  fields = line.split("\t")
  longitud  = len(fields)
  if longitud > 1:
    categoria = fields[3]
    views = int(fields[5])
    return (categoria, views)
  else:
    categoria = 'None'
    views = int ('0')
    return (categoria, views)

def maximo(accum, value):
  max = accum
  if value > accum:
    max = value 
  return max 
#inicializacion
spark = SparkSession.builder.appName('visitas').getOrCreate()


entrada = sys.argv[1]
salida1 = sys.argv[2]


data= spark.sparkContext.textFile(entrada)
ratings = data.map(clavevalor).reduceByKey( lambda x,y: x + y).reduceByKey(maximo).first()
rdd = spark.sparkContext.parallelize([ratings],1)

#ratings = data.map(filtrar)
rdd.saveAsTextFile(salida1)