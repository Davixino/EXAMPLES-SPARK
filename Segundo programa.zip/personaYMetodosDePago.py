#!/usr/bin/python3

import sys

from pyspark.sql import SparkSession

'''
Programa creado por Ronald Jimenez
'''

def pagomax(linea):
  nombre, tarjeta, pago = linea.split(";", 2)
  num = int (pago)
  if num > 1500:
	  	pago = 1
  else:
	  	pago = 0 
  rdd = (nombre, tarjeta, pago)
  rdd2 = tarjetamax(nombre, tarjeta, pago)
  return rdd2

def pagommin(linea):
  nombre, tarjeta, pago = linea.split(";", 2)
  num = int (pago)
  if num < 1500:
	  	pago = 1
  else:
	  	pago = 0 
  rdd4 = (nombre, tarjeta, pago)
  rdd5 = tarjetamin(nombre, tarjeta, pago)
  return rdd5


def tarjetamax(nombre, tarjeta, pago):
  if tarjeta != 'Tarjeta de credito':
    pago = 0
  rdd3 = (nombre, pago)
  return rdd3

def tarjetamin(nombre, tarjeta, pago):
  if tarjeta != 'Tarjeta de credito':
    pago = 0
  rdd6 = (nombre, pago)
  return rdd6

#inicializacion
spark = SparkSession.builder.appName('pago').getOrCreate()

entrada = sys.argv[1]
##salida1 = sys.argv[2]
#salida2 = sys.argv[3]

datosentrada= spark.sparkContext.textFile(entrada)

conteo=datosentrada.map(pagomax).reduceByKey(lambda x,y: x+y)
conteo2=datosentrada.map(pagommin).reduceByKey(lambda x,y: x+y)
conteomin = conteo2.repartition(1)
conteomax = conteo.repartition(1)
conteomax.saveAsTextFile("SalidaMax")
conteomin.saveAsTextFile("SalidaMin")