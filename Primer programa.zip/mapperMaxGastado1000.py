#!/usr/bin/python3
import sys
'''
Mapper de max1000
Creado por Ronald Jimenez
'''
for linea in sys.stdin:
	linea = linea.strip()
	nombre, pago = linea.split(";",1)
	print("%s\t%s" % (nombre, pago))
