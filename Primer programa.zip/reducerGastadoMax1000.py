#!/usr/bin/python3
import sys
'''
Mapper de max1000
Creado por Ronald Jimenez
'''

subproblema = None

suma = None



for clavevalor in sys.stdin:
	nombre, pago = clavevalor.split("\t",1) 

	#Convertirmos pago a int
	pago= float(pago)
	#El primer subproblema es el primer nombre y la temp maxima de momento tambien
	if subproblema == None:
		subproblema = nombre #Alice
		suma=0
		
	if subproblema == nombre:  #alice
		#print ("%s" + clavevalor)
		suma += pago	
	else:
		if suma > 1000:
			print ("%s\t%s" % (subproblema, suma))
		subproblema = nombre
		suma=0	
if suma > 1000:
	print ("%s\t%s" % (subproblema, suma))
		
		
		
		
		



	



